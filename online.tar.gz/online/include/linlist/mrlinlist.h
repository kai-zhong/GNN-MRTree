#pragma once

#include <stdio.h>
#include "func/gendef.h"

class MRTree;

struct MRLinkable
{
public:
    int son;
    int dimension;
    int level;
    double *bounces;
    double distanz;
    unsigned char digest[SHA256_DIGEST_LENGTH];

    MRLinkable(int dim)
    {
        dimension = dim;
        bounces = new double[2 * dim];
    }

    ~MRLinkable()
    {
        delete [] bounces;
    }
};

struct MRSLink
{
    MRLinkable *d;
    MRSLink *next;
    MRSLink *prev;

    MRSLink();
    ~MRSLink();
};

class MRLinList
{
protected:
    MRSLink *first;
    MRSLink *last;
    int anz;
    MRSLink *akt;
    int akt_index;

public:
    MRLinList();
    virtual ~MRLinList();
    int get_num(){return anz;}

    void check();
    void print();

    void insert(MRLinkable *f);

    bool erase();

    MRLinkable * get(int i);
    MRLinkable * get_first();
    MRLinkable * get_last();
    MRLinkable * get_next();
    MRLinkable * get_prev();
};

class MRSortedLinList : public MRLinList
{
    bool increasing;
public: 
    MRSortedLinList();

    void set_sorting(bool _increasing);

    void insert(MRLinkable *f);

    void sort(bool _increasing);
};