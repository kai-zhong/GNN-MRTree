#pragma once


#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <unordered_map>
#include <unordered_set>
#include <vector>
#include <queue>
#include <openssl/sha.h>

#define BFHEAD_LENGTH (sizeof(int)*2)    

#define TRUE 1
#define FALSE 0

#define SEEK_CUR 1
#define SEEK_SET 0
#define SEEK_END 2

typedef char Block[];

#define MAXREAL         1e20
#define doubleZERO       1e-20
#define MAX_DIMENSION   256

#define DIMENSION 2

#define TRUE 1
#define FALSE 0

#define MIN(a, b) (((a) < (b))? (a) : (b)  )
#define MAX(a, b) (((a) > (b))? (a) : (b)  )

class BlockFile;  
class Cache;
class Cacheable   
{
public:
	BlockFile *file;
	Cache *cache;
};
  
class Auxiliary_Data {
public:
    int main_dim;  
    int associate_dim;  

    double *mbr_zero_main;  
    double *mbr_zero_associate;  
    double *mbr_associate;  
    
    int *degrees;  

    Auxiliary_Data() {}

    Auxiliary_Data(int main_dim, int associate_dim, int path_length) {
        
        this->main_dim = main_dim;
        
        this->associate_dim = associate_dim;
        
        mbr_zero_main = new double[main_dim * 2];
        
        mbr_associate = new double[associate_dim * 2];
        
        mbr_zero_associate = new double[associate_dim * 2];

        degrees = new int[path_length];
    }

    ~Auxiliary_Data() 
    {
        delete[] mbr_zero_main;
        delete[] mbr_zero_associate;
        delete[] mbr_associate;
        delete[] degrees;
    }
};



class Query_Path_MBR
{
public:
    int main_dim;          
    int associate_dim;     
    int ID;                
    int path_length;       
    double key;            

    std::vector<double> mbr_main;           
    std::vector<double> mbr_associate;      
    std::vector<double> mbr_zero_main;      
    std::vector<double> mbr_zero_associate; 
    std::vector<int> node_degrees;          

    
    Query_Path_MBR() {}
    
    Query_Path_MBR(int ID, int main_dim, int associate_dim, int path_length)
    {
        this->ID = ID;
        this->main_dim = main_dim;
        this->associate_dim = associate_dim;
        this->path_length = path_length;
    }
    
    void calculate_key()
    {
        key = 0;
        
        for (int i = 0; i < main_dim; i++)
        {
            key += -abs(mbr_main[i * 2]); 
        }
    }
};


class Query_Plan
{
public:
    std::vector<Query_Path_MBR> query_mbrs; 
    double key;                        
    
    Query_Plan() {}
    
    Query_Plan(std::vector<Query_Path_MBR> mbrs)
    {
        query_mbrs = mbrs;
    }
    
    void calculate_key()
    {
        key = -10000; 
        
        for (int i = 0; i < query_mbrs.size(); i++)
        {
            if (query_mbrs[i].key > key)
            {
                key = query_mbrs[i].key; 
            }
        }
    }
    
    void calculate_key(int length)
    {
        key = -10000; 
        
        for (int i = 0; i < length; i++)
        {
            if (query_mbrs[i].key > key)
            {
                key = query_mbrs[i].key; 
            }
        }
    }
};

class NodeTracker
{
	private:
		int nodes_num; 
		int dimension; 
    
		std::unordered_map<int, std::vector<int>> nodes_visited_entry; 
		std::unordered_map<int, std::unordered_set<int>> seen_entries; 
		
	public:
		NodeTracker(int _nodes_num, int _dimension)
		{
			this->dimension = _dimension;
			this->nodes_num = _nodes_num;
			for (int i = 0; i < nodes_num; i++)
			{
				nodes_visited_entry[i] = std::vector<int>();
				seen_entries[i] = std::unordered_set<int>();
			}
		}

		void clean()
		{
			nodes_visited_entry.clear();
			seen_entries.clear();

			
			for (int i = 0; i < nodes_num; i++)
			{
				nodes_visited_entry[i] = std::vector<int>();
				seen_entries[i] = std::unordered_set<int>();
			}
		}

		void insert(int block_id, int entry_id)
		{
				
			if (seen_entries[block_id].find(entry_id) == seen_entries[block_id].end()) 
			{
				
				nodes_visited_entry[block_id].push_back(entry_id);
				seen_entries[block_id].insert(entry_id);
			}
		}

		const std::vector<int>& operator[](int block) const 
		{
			auto it = nodes_visited_entry.find(block);
        	if (it == nodes_visited_entry.end())
			{
				printf("block %d not exist\n", block);
			}
			return nodes_visited_entry.at(block); 
		}
};

class CmdIntrpr  
{
public:
	int cnfrm_cmd(char *_msg)
	{ char c = ' ';
	  while (c != 'N' && c != 'Y')
	  { printf("%s (y/n)?", _msg);
	    c = getchar(); 
		char tmp;
		while ((tmp = getchar()) != '\n');
		c = toupper(c); }
	  if (c == 'N') return 0; else return 1; }
  
	void get_cmd(char *_msg, char *_cmd)
	{ printf("%s", _msg);  
	  char *c = _cmd;
	  while (((*c) = getchar()) != '\n')
	    c++;
	  *c = '\0'; } 

	virtual bool build_tree(char *_tree_fname, char *_data_fname, int _b_len, int _dim, int _csize) = 0;
	virtual void free_tree() = 0;
	virtual int qry_sngle(double *_mbr, int *_io_count) = 0;
	/*
	virtual int qry_wrkld(char *_wrkld_fname, int *_io_count, bool _display) = 0;
	*/
	virtual void run() = 0;
	virtual void version() = 0;
};
  
enum SECTION {OVERLAP, INSIDE, S_NONE}; 
enum R_OVERFLOW {SPLIT, REINSERT, NONE}; 
enum R_DELETE {NOTFOUND,NORMAL,ERASED}; 
typedef double *doubleptr;
  

struct SortMbr
{
    int dimension;
    double *mbr;
    double *center;
    int index;
};

struct BranchList
{
    int entry_number;
    double mindist;
    double minmaxdist;
    bool section;
};

struct VOData 
{
	int dimension;
    double* mbr = nullptr;
    unsigned char digest[SHA256_DIGEST_LENGTH];

    
    VOData(double* _mbr, const unsigned char* _digest, int _dimension) 
	{
		dimension = _dimension;
        mbr = new double[2 * dimension]; 
        memcpy(mbr, _mbr, 2 * dimension * sizeof(double));
		memcpy(digest, _digest, SHA256_DIGEST_LENGTH);
    }
	
    VOData(const VOData& other) 
	{
		dimension = other.dimension;
        mbr = new double[2 * dimension];
        memcpy(mbr, other.mbr, 2 * dimension * sizeof(double));
        memcpy(digest, other.digest, SHA256_DIGEST_LENGTH);
    }

    ~VOData() 
	{
		delete[] mbr;
    }
};

struct VOEntry
{
    enum DataType { DOUBLE, DATA, SPECIAL };
	int dimension;
    DataType type;
	int id;
    union 
	{
        double* mbr;
        VOData data;
        char specialChar;
    };

    VOEntry (double* _mbr, int _path_id, int _dimension) : type(DOUBLE) 
	{
		if(_mbr == nullptr)
			printf("NULL MBR\n");
		dimension = _dimension;
		id = _path_id;
        mbr = new double[2 * _dimension];
		memcpy(mbr, _mbr, 2 * _dimension * sizeof(double));
    }
    
    VOEntry (const VOData& _data, int _node_id) : type(DATA) 
	{
		id = _node_id;
		dimension = _data.dimension;
		data.dimension = _data.dimension;
		data.mbr = new double[2 * dimension];
		memcpy(data.mbr, _data.mbr, 2 * dimension * sizeof(double));
		memcpy(data.digest, _data.digest, SHA256_DIGEST_LENGTH);
    }

    VOEntry (char _special) : type(SPECIAL) 
	{
        specialChar = _special;
    }
	
    VOEntry(const VOEntry& other) : type(other.type) 
	{
        switch (type) 
		{
            case DOUBLE:
				dimension = other.dimension;
				id = other.id;
                mbr = new double[2 * dimension]; 
                memcpy(mbr, other.mbr, 2 * dimension* sizeof(double));
                break;
            case DATA:
				id = other.id;
				dimension = other.dimension;
                data.dimension = other.dimension;
				data.mbr = new double[2 * data.dimension];
				memcpy(data.mbr, other.data.mbr, 2 * dimension * sizeof(double));
				memcpy(data.digest, other.data.digest, SHA256_DIGEST_LENGTH);
				break;
            case SPECIAL:
                specialChar = other.specialChar;
                break;
        }
    }
    
    ~VOEntry () 
	{
        switch (type) 
        {
            case DOUBLE:
                delete[] mbr; 
                break;
            case DATA:
				delete[] data.mbr;
                
                break;
            case SPECIAL:
                
                break;
        }
    }
};


void error(char *_errmsg, bool _terminate);

double area(int dimension, double *mbr);
double margin(int dimension, double *mbr);
double overlap(int dimension, double *r1, double *r2);
double* overlapRect(int dimension, double *r1, double *r2);
double objectDIST(double *p1, double *p2);
double MINMAXDIST(double *Point, double *bounces);
double MINDIST(double *Point, double *bounces, int Pdim);
double MAXDIST(double *p, double *bounces, int dim);
double MbrMINDIST(double *_m1, double *_m2, int _dim);
double MbrMAXDIST(double *_m1, double *_m2, int _dim);

bool inside(double &p, double &lb, double &ub);
void enlarge(int dimension, double **mbr, double *r1, double *r2);
void enlarge2(double** mbr, double* r1, int dimension);
bool is_inside(int dimension, double *p, double *mbr);
int pruneBrunchList(double *nearest_distanz, const void *activebrunchList, 
		    int n);
bool section(int dimension, double *mbr1, double *mbr2);
bool section_c(int dimension, double *mbr1, double *center, double radius);

int sort_lower_mbr(const void *d1, const void *d2);
int sort_upper_mbr(const void *d1, const void *d2);
int sort_center_mbr(const void *d1, const void *d2);
int sortmindist(const void *element1, const void *element2);

#ifdef UNIX
void strupr(char *_msg);
#endif
