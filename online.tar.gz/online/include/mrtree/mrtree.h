#pragma once

#include "func/gendef.h"
#include "heap/heap.h"

class MRLinList;
class MRSortedLinList;
class Cache;
class MRTNode;
class MREntry;

class MRTree : public Cacheable
{
public:

    int dimension;
    int num_of_data;
    int num_of_dnodes; 
    int num_of_inodes; 
    int root;
    bool root_is_data;

    MRTNode *root_ptr;
    bool *re_level;
    MRLinList *re_data_cands;
    MRLinList *deletelist;

    int na[10];

    MRTree(char *fname, int _b_length, Cache *c, int _dimension);

    MRTree(char *fname, Cache *c);

    MRTree(char *inpname, char *fname, int _blength, Cache *c, int _dimension);

    ~MRTree();

    bool delete_entry(MREntry *e);

    bool FindLeaf(MREntry *e);

    int get_num() { return num_of_data; };

    void insert(MREntry *d);

    void load_root();

    void NNQuery(double *QueryPoint, MRSortedLinList *res);

    void rangeQuery(double *mbr, MRSortedLinList *res);

    void read_header(char *buffer);

    void write_header(char *buffer);

    double get_score_linear(MREntry *e, double *_weight, int _dimension);

    double get_score_linear(double *_mbr, double *_weight, int _dimension);

    double get_score_range(MREntry *e, double *_weight, int _dimension, double *_range);

    double get_score_linear(MREntry *_e, double *_weight, int _dimension, 
							  double SCORE_FUNC(const double *, const double *, int));

    void rank_qry_constr_linear(double *_weight, double *_qmbr, int _k, Heap *_hp, int *_rslt);
	void rank_qry_inquiry(double *_weight, double _qscore, int *_rslt);
	void rank_qry_linear(double *_weight, int _k, Heap *_hp, int *_rslt);
	void rank_qry_monotone(double *_weight, int _k, Heap *_hp, int *_rslt, 
							double SCORE_FUNC(const double *, const double *, int));

	void kNN(double *_q, int _k, Heap *_hp, double &fardist);

    void search(Query_Plan& Q, std::vector<VOEntry>& VO, std::vector<std::vector<int>>& candidates, NodeTracker* tracker, Auxiliary_Data** auxiliary_index, double** path_zero_main_embeddings, double** path_one_associate_embeddings, int path_main_dim, int path_associate_dim);

    void compute_digest();

    void get_root_digest(unsigned char* buffer);

    void generate_VO(std::vector<VOEntry>& VO, const NodeTracker& nodeTracker);
};