#pragma once

#include "func/gendef.h"

class MRSortedLinList;
class MREntry;
class MRTree;
class Heap;

class MRTNode
{
public:

    char level;
    int block;
    int num_entries;
    MREntry *entries;
    
    unsigned char digest[SHA256_DIGEST_LENGTH];

    bool dirty;
    int capacity;
    int dimension;
    MRTree *my_tree;

    MRTNode(MRTree *rt);

    MRTNode(MRTree *rt, int _block);

    ~MRTNode();

    int choose_subtree(double *brm);

    R_DELETE delete_entry(MREntry *e);

    void enter(MREntry *de);

    bool FindLeaf(MREntry *e);

    double *get_mbr();

    int get_num_of_data();

    int get_num_of_node();

    R_OVERFLOW insert(MREntry *d, MRTNode **sn);

    bool is_data_node() {return (level == 0) ? TRUE : FALSE;};

    void NNSearch(double *QueryPoint, MRSortedLinList *res, double *nearest_distanz);

    void print();

    void rangeQuery(double *mbr, MRSortedLinList *res);

    void read_from_buffer(char *buffer);

    int split(double **mbr, int **distribution);

    void split(MRTNode *sn);

    void write_to_buffer(char *buffer);

    void rank_qry_inquiry(double *_weight, double _qscore, int *_rslt);

    void search(Query_Plan& Q, std::vector<VOEntry>& VO, std::vector<std::vector<int>>& candidates, 
                NodeTracker* tracker, Auxiliary_Data** auxiliary_index, double** path_zero_main_embeddings, 
                double** path_one_associate_embeddings, int path_main_dim, int path_associate_dim);

    void compute_digest();

    void compute_HRoot();

    void generate_VO(std::vector<VOEntry>& VO, const NodeTracker& nodeTracker);
};