#pragma once

#include "func/gendef.h"

class MRTNode;
class MRTree;
struct MRLinkable;

class MREntry
{
public:
    int son;
    double *bounces;
    unsigned char digest[SHA256_DIGEST_LENGTH];

    int dimension;
    int level;
    MRTree *my_tree;
    MRTNode *son_ptr;

    MREntry();
    MREntry(int dimension, MRTree *mrt);
    ~MREntry();

    void del_son();
    MRLinkable *gen_Linkable();
    int get_size();
    MRTNode *get_son();
    void init_entry(int _dimension, MRTree *_mrt);
    void read_from_buffer(char *buffer);
    SECTION section(double *mbr);
    bool section_circle(double *center, double radius);
    void set_from_Linkable(MRLinkable *link);
    void write_to_buffer(char *buffer);
    void compute_digest(bool is_leaf);

    virtual MREntry & operator = (MREntry &_d);
    bool operator == (MREntry &_d);
};