#include "mrtree/mrtree.h"
#include "mrtree/mrtnode.h"
#include "mrtree/mrentry.h"
#include "./blockfile/blk_file.h"
#include "./blockfile/cache.h"
#include "linlist/mrlinlist.h"
#include "rand.h"
#include "cdf.h"

#include "./graph/graph.h"
#include "custom.h"

#define NOMINMAX
#undef min
#undef max

#include <cmath>
#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <iostream>
#include <stdio.h>
#include <string.h>
#include <fstream>
#include <string>
#include <queue>
#include <set>
#include <vector>
#include <map>
#include <omp.h>
#include <chrono>
#include <cstdio>

using namespace std;
using namespace chrono;

string dataset_path = "Datasets/yeast/";

int embedding_dimension = 2;
int partition_number = 5;
int GNN_number = 3;
int path_length = 2;
int path_nodes = path_length + 1;
int query_number = 100;


void print_mbr(int dimension, double* mbr)
{
    std::cout<<"MBR : (";
    for(int i = 0; i < 2 * dimension; i++)
    {
        if(i != 2 * dimension - 1)
            std::cout<<mbr[i]<<",";
        else
            std::cout<<mbr[i];
    }
    std::cout<<")"<<std::endl;
}

void print_digest(unsigned char* digest)
{
    std::cout<<"Hash digest : ";
    for (size_t i = 0; i < SHA256_DIGEST_LENGTH; i++) 
    {
        printf("%02x", digest[i]);
    }
    std::cout<<std::endl;
}

void appendStr(unsigned char*& str, double* mbr, unsigned char* digest, int dimension, int& currentSize) 
{
    int mbrSize = 2 * dimension * sizeof(double);
    
    int total_length = mbrSize + SHA256_DIGEST_LENGTH;
    unsigned char* buffer = new unsigned char[total_length];
    unsigned char new_Digest[SHA256_DIGEST_LENGTH];
    str = static_cast<unsigned char*>(realloc(str, currentSize + SHA256_DIGEST_LENGTH));

    if (str == nullptr) 
    {
        std::cerr << "Memory allocation failed!" << std::endl;
        return;
    }

    memcpy(buffer, mbr, mbrSize);

    memcpy(buffer + mbrSize, digest, SHA256_DIGEST_LENGTH);

    SHA256(buffer, total_length, new_Digest);

    memcpy(str + currentSize, new_Digest, SHA256_DIGEST_LENGTH);
    currentSize += SHA256_DIGEST_LENGTH;

    delete[] buffer;
}

void appendStr2(unsigned char*& str, double* mbr, int dimension, int& currentSize) 
{
    int mbrSize = 2 * dimension * sizeof(double);
    
    int newSize = currentSize + SHA256_DIGEST_LENGTH;

    str = static_cast<unsigned char*>(realloc(str, newSize));
    
    if (str == nullptr) 
    {
        std::cerr << "Memory allocation failed!" << std::endl;
        return;
    }

    int total_length = 2 * dimension * sizeof(double);
    unsigned char *buffer = new unsigned char[total_length];
    unsigned char digest[SHA256_DIGEST_LENGTH];
    memcpy(buffer, mbr, total_length);
    SHA256(buffer, total_length, digest);
    memcpy(str + currentSize, digest, SHA256_DIGEST_LENGTH);
    currentSize += SHA256_DIGEST_LENGTH;
	delete buffer;
}

void appendStr3(unsigned char*& str, unsigned char* digest, int& currentSize) 
{
    str = static_cast<unsigned char*>(realloc(str, currentSize + SHA256_DIGEST_LENGTH));

    if (str == nullptr) 
    {
        std::cerr << "Memory allocation failed!" << std::endl;
        return;
    }

    memcpy(str + currentSize, digest, SHA256_DIGEST_LENGTH);
    currentSize += SHA256_DIGEST_LENGTH;
}

bool areEqual(const std::vector<int>& vec1, const std::vector<int>& vec2) 
{
    if (vec1.size() != vec2.size()) return false;

    std::unordered_multiset<int> set1(vec1.begin(), vec1.end());
    std::unordered_multiset<int> set2(vec2.begin(), vec2.end());

    return set1 == set2;
}

bool areVectorsEqual(const std::vector<std::vector<int>>& a, const std::vector<std::vector<int>>& b) 
{
    if (a.size() != b.size()) return false;

    for (size_t i = 0; i < a.size(); ++i) 
	{
        if (!areEqual(a[i], b[i])) 
		{
            return false;
        }
    }
    return true;
}

VOData parse_VO(std::queue<VOEntry>& VO, const Query_Plan& Q, vector<vector<int>>& verify_candidates, 
				vector<vector<int>>& candidates, double**& path_zero_main_embeddings, 
				double**& path_one_associate_embeddings, Auxiliary_Data**& auxiliary_index, 
				int dimension, int associate_dimension, bool& verification_res) 
{
    unsigned char* str = nullptr;
    double* minmbr = nullptr;
    int str_len = 0;
    while(!VO.empty())
    {
        VOEntry temp_entry = VO.front();
        VO.pop();
        switch (temp_entry.type)
        {
            case VOEntry::DOUBLE:
				if(verification_res == true)
				{
					int path_ID = temp_entry.id;
					for(int j = 0; j < Q.query_mbrs.size(); j++)
					{
						int k = 0;

						for(; k < dimension; k++)
						{
							if(Q.query_mbrs[j].mbr_zero_main[2 * k] != path_zero_main_embeddings[path_ID][k])
							{
								break;
							}
						}
						if(k == dimension)
						{
							k = 0;

							for(; k < dimension; k++)
							{
								if(Q.query_mbrs[j].mbr_main[2 * k] > temp_entry.mbr[2 * k + 1])
								{
									break;
								}
							}
							if(k == dimension)
							{
								k = 0;

								for(; k < associate_dimension; k++)
								{
									if(Q.query_mbrs[j].mbr_associate[2 * k] > path_one_associate_embeddings[path_ID][k])
									{
										break;
									}
								}
								if(k == associate_dimension)
								{
									verify_candidates[Q.query_mbrs[j].ID].push_back(path_ID);
								}
							}
						}
					}
				}
                enlarge2(&minmbr, temp_entry.mbr, dimension);
                appendStr2(str, temp_entry.mbr, dimension, str_len);
                break;

            case VOEntry::DATA:
				if(verification_res == true)
				{
					int node_ID = temp_entry.id;
					for(int j = 0; j < Q.query_mbrs.size(); j++)
					{
						int k = 0;
						for(; k < dimension; k++)
						{
							if(Q.query_mbrs[j].mbr_zero_main[2 * k] > auxiliary_index[node_ID]->mbr_zero_main[2 * k + 1] || 
							Q.query_mbrs[j].mbr_zero_main[2 * k] < auxiliary_index[node_ID]->mbr_zero_main[2 * k])
							{
								break;
							}
						}
						if(k == dimension)
						{
							k = 0;
							for(; k < dimension; k++)
							{
								if(Q.query_mbrs[j].mbr_main[2 * k] > temp_entry.data.mbr[2 * k + 1])
								{
									break;
								}
							}
							if(k == dimension)
							{
								k = 0;
								for(; k < associate_dimension; k++)
								{
									if(Q.query_mbrs[j].mbr_associate[2 * k] > auxiliary_index[node_ID]->mbr_associate[2 * k + 1])
									{
										break;
									}
								}
								if(k == associate_dimension)
								{
									verification_res = false;
								}
							}
						}
					}
				}

                enlarge2(&minmbr, temp_entry.data.mbr, dimension);
                appendStr(str, temp_entry.data.mbr, temp_entry.data.digest, dimension, str_len);
                break;

            case VOEntry::SPECIAL:
                if(temp_entry.specialChar == '[')
                {
                    VOData vodata_c = parse_VO(VO, Q, verify_candidates, candidates, 
												path_zero_main_embeddings, path_one_associate_embeddings, 
												auxiliary_index, dimension, associate_dimension, 
												verification_res);
                    enlarge2(&minmbr, vodata_c.mbr, dimension);
                    appendStr(str, vodata_c.mbr,vodata_c.digest,dimension, str_len);
                }
                else if(temp_entry.specialChar == ']')
                {
                    unsigned char digest[SHA256_DIGEST_LENGTH];
                    SHA256(str, str_len, digest);
                    VOData ret(minmbr, digest, dimension);
					delete[] str;
					delete[] minmbr;
                    return ret;
                }
                break;

            default:
                break;
        }
    }
	if(verification_res == true)
	{
		if(areVectorsEqual(verify_candidates, candidates))
			std::cout<<"verification : true"<<std::endl;
		else
			std::cout<<"verification : false"<<std::endl;
	}
	else
		std::cout<<"verification : false"<<std::endl;

    VOData _ret(minmbr, str, dimension);
	delete[] str;
	delete[] minmbr;
    return _ret;
}

void vectorToQueue(const std::vector<VOEntry>& vec, std::queue<VOEntry>& q) 
{
    int i = 0;
    for (const auto& vo : vec) 
    {
        q.push(vo);
    }
}

int main()
{
	string filename = dataset_path + "data_graph.txt";
	Graph *data_graph = new Graph(true);
	data_graph->loadGraphFromFile(filename);
	data_graph->printGraphMetaData();

	Partition **partitions = new Partition *[partition_number];
	for (int i = 0; i < partition_number; i++)
	{
		filename = dataset_path + "Partition-" + to_string(i) + "/";
		partitions[i] = new Partition(filename, GNN_number, query_number, data_graph);

		cout << endl << "Partition " << to_string(i) << ":" << endl;

		partitions[i]->build_index();
	}

	filename = dataset_path + "query_graphs/";
	Query_Graph **query_graphs = new Query_Graph *[query_number];
	double query_time = 0;
	double sum_verify_time = 0;
	for (int query_ID = 0; query_ID < query_number; query_ID++)
	{
		query_graphs[query_ID] = new Query_Graph(filename, query_ID);

		double query_plan_time = query_graphs[query_ID]->generate_query_plan_2();

		double search_time = 0;

		vector<vector<Candidate_Path>> global_candidates(query_graphs[query_ID]->query_plan.size());
		vector<vector<int>> global_boundary(query_graphs[query_ID]->query_plan.size());

		vector<vector<vector<int>>> candidates(partition_number);

#pragma omg parallel for num_threads(partition_number)

		double verify_time = 0;
		for (int i = 0; i < partition_number; i++)
		{
			Query_Plan Q;

			search_time += partitions[i]->query(query_graphs[query_ID], query_ID, candidates[i], Q);

			std::queue<VOEntry> _VO;
			vectorToQueue(partitions[i]->VO, _VO);
			partitions[i]->VO.clear();

			bool verification_res = true;
			vector<vector<int>> verify_candidates(Q.query_mbrs.size());
			typedef chrono::high_resolution_clock Clock;
			auto start_verify_time = Clock::now();
			VOData retData = parse_VO(_VO, Q, verify_candidates, candidates[i], 
									partitions[i]->path_zero_main_embeddings, 
									partitions[i]->path_one_associate_embeddings, 
									partitions[i]->auxiliary_index, partitions[i]->path_main_dim, 
									partitions[i]->path_associate_dim, verification_res);
			auto end_verify_time = Clock::now();
			verify_time += chrono::duration_cast<chrono::nanoseconds>(end_verify_time - start_verify_time).count() / 1e+6;
		}
		verify_time /= partition_number;
		sum_verify_time += verify_time;
		search_time /= partition_number;

		for (int i = 0; i < partition_number; i++)
		{
			for (int j = 0; j < global_candidates.size(); j++)
			{
				for (int k = 0; k < candidates[i][j].size(); k++)
				{
					int path_ID = candidates[i][j][k];
					vector<int> tmp_path(partitions[i]->paths[path_ID], partitions[i]->paths[path_ID] + path_nodes);
					global_boundary[j].push_back(partitions[i]->path_boundary[path_ID]);

					for (int l = 0; l < tmp_path.size(); l++)
					{
						tmp_path[l] = partitions[i]->graph_extend_map[tmp_path[l]];
					}

					global_candidates[j].push_back(Candidate_Path(tmp_path));
				}
			}
		}

		double join_time = 0;

		for (int i = 0; i < global_candidates.size(); i++)
		{
			vector<Query_Path> query_plan;
			query_plan.push_back(query_graphs[query_ID]->query_plan[i]);
			for (int j = 0; j < query_graphs[query_ID]->query_plan.size(); j++)
			{
				if (j != i)
				{
					query_plan.push_back(query_graphs[query_ID]->query_plan[j]);
				}
			}

			vector<unordered_map<int, int>> key_cols(query_plan.size());
			for (int cur_path = 1; cur_path < query_plan.size(); cur_path++)
			{
				for (int cur_node = 0; cur_node < path_nodes; cur_node++)
				{
					for (int j = 0; j < cur_path; j++)
					{
						for (int k = 0; k < path_nodes; k++)
						{
							if (query_plan[cur_path].nodes[cur_node] == query_plan[j].nodes[k])
							{
								auto it = key_cols[cur_path].find(cur_node);
								if (it == key_cols[cur_path].end())
								{
									key_cols[cur_path].insert({cur_node, j * path_nodes + k});
								}
							}
						}
					}
				}
			}

			vector<vector<Candidate_Path>> global_candidates_resort;
			global_candidates_resort.push_back(global_candidates[i]);
			for (int j = 0; j < query_graphs[query_ID]->query_plan.size(); j++)
			{
				if (j != i)
				{
					global_candidates_resort.push_back(global_candidates[j]);
				}
			}

			vector<vector<vector<int>>> tables(global_candidates.size());
			for (int j = 0; j < global_candidates.size(); j++)
			{
				if (j == i)
				{
					for (int k = 0; k < global_candidates[j].size(); k++)
					{
						if (global_boundary[j][k] == 1)
						{
							tables[j].push_back(global_candidates[j][k].nodes);
						}
					}
				}
				else
				{
					for (int k = 0; k < global_candidates[j].size(); k++)
					{
						tables[j].push_back(global_candidates[j][k].nodes);
					}
				}
			}
			vector<vector<int>> result;

			unordered_map<Key, vector<int>> hash_map;

			vector<int> col_indices_a;
			vector<int> col_indices_b;

			typedef chrono::high_resolution_clock Clock;
			auto start_time = Clock::now();

			for (const auto &pair : key_cols[1])
			{
				col_indices_a.push_back(pair.second);
				col_indices_b.push_back(pair.first);
			}
			vector<vector<int>> keys_a(tables[0].size(), vector<int>(col_indices_a.size()));
			transform(tables[0].begin(), tables[0].end(), keys_a.begin(),
					  [&col_indices_a](const vector<int> &row)
					  {
						  vector<int> col_data;
						  for (int col_index : col_indices_a)
						  {
							  col_data.push_back(row.at(col_index));
						  }
						  return col_data;
					  });
			vector<vector<int>> keys_b(tables[1].size(), vector<int>(col_indices_b.size()));
			transform(tables[1].begin(), tables[1].end(), keys_b.begin(),
					  [&col_indices_b](const vector<int> &row)
					  {
						  vector<int> col_data;
						  for (int col_index : col_indices_b)
						  {
							  col_data.push_back(row.at(col_index));
						  }
						  return col_data;
					  });

			for (int i = 0; i < tables[1].size(); ++i)
			{
				Key key{keys_b[i]};
				hash_map[key].push_back(i);
			}

			for (int i = 0; i < tables[0].size(); ++i)
			{
				if (result.size() > table_max_size)
				{
					break;
				}

				Key key{keys_a[i]};
				if (hash_map.count(key))
				{
					for (int j : hash_map[key])
					{
						if (result.size() > table_max_size)
						{
							break;
						}

						vector<int> row;
						row.insert(row.end(), tables[0][i].begin(), tables[0][i].end());
						row.insert(row.end(), tables[1][j].begin(), tables[1][j].end());
						result.push_back(row);
					}
				}
			}

			for (int t = 2; t < tables.size(); ++t)
			{
				vector<vector<int>> tmp_result;
				hash_map.clear();
				col_indices_a.clear();
				col_indices_b.clear();

				for (const auto &pair : key_cols[t])
				{
					col_indices_a.push_back(pair.second);
					col_indices_b.push_back(pair.first);
				}

				vector<vector<int>> keys_a(result.size(), vector<int>(col_indices_a.size()));
				transform(result.begin(), result.end(), keys_a.begin(),
						  [&col_indices_a](const vector<int> &row)
						  {
							  vector<int> col_data;
							  for (int col_index : col_indices_a)
							  {
								  col_data.push_back(row.at(col_index));
							  }
							  return col_data;
						  });

				vector<vector<int>> keys_b(tables[t].size(), vector<int>(col_indices_b.size()));
				transform(tables[t].begin(), tables[t].end(), keys_b.begin(),
						  [&col_indices_b](const vector<int> &row)
						  {
							  vector<int> col_data;
							  for (int col_index : col_indices_b)
							  {
								  col_data.push_back(row.at(col_index));
							  }
							  return col_data;
						  });

				int p = result.size();
				for (int i = 0; i < p; ++i)
				{
					Key key{keys_a[i]};
					hash_map[key].push_back(i);
				}

				for (int i = 0; i < tables[t].size(); ++i)
				{
					if (tmp_result.size() > table_max_size)
					{
						break;
					}

					Key key{keys_b[i]};
					if (hash_map.count(key))
					{
						for (int j : hash_map[key])
						{
							if (tmp_result.size() > table_max_size)
							{
								break;
							}
							vector<int> row;
							row.insert(row.end(), result[j].begin(), result[j].end());
							row.insert(row.end(), tables[t][i].begin(), tables[t][i].end());
							tmp_result.push_back(row);
						}
					}
				}
				result = tmp_result;
			}
			auto end_time = Clock::now();

			join_time += chrono::duration_cast<chrono::nanoseconds>(end_time - start_time).count() / 1e+6;
		}
		join_time /= global_candidates.size();

		query_time += query_plan_time + search_time + join_time;

		cout << "query graph ID: " << query_ID << endl;

		cout << "verify time : "<< verify_time << endl;

		cout << "query plane generation time: " << query_plan_time << " index search time: " << search_time << " hash join time: " << join_time << " query time: " << query_plan_time + search_time + join_time << endl;
	}

	cout << endl << "Query Number: " << query_number << endl;
	printf("Average Verify Time(ms): %.4f\n", sum_verify_time / (1.0 * query_number));
	printf("Average Query Time(ms): %.4f\n", query_time / (1.0 * query_number));

	return 0;
}
