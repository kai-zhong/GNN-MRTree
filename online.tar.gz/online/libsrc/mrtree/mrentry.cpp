#include <stdio.h>
#include <iostream>
#include <math.h>
#include <string.h>
#include "mrtree/mrentry.h"
#include "mrtree/mrtnode.h"
#include "linlist/mrlinlist.h"

MREntry::MREntry()
{
    son_ptr = NULL;
    bounces = NULL;
    memset(digest, 0x0, SHA256_DIGEST_LENGTH);
}

MREntry::MREntry(int _dimension, MRTree *mrt)
{
    dimension = _dimension;
    my_tree = mrt;
    bounces = new double[2*dimension];
    son_ptr = NULL;
    son = 0;
    level = 0;
    memset(digest, 0x0, SHA256_DIGEST_LENGTH);
}

MREntry::~MREntry()
{
    if(bounces)
        delete [] bounces;
    if(son_ptr != NULL)
        delete son_ptr;
}

void MREntry::del_son()
{
    if(son_ptr != NULL)
    {
        delete son_ptr;
        son_ptr = NULL;
    }
}

MRLinkable* MREntry::gen_Linkable()
{
    MRLinkable *new_link = new MRLinkable(dimension);
    new_link->son = son;
    
    for(int i = 0; i < 2 * dimension; i++)
        new_link->bounces[i] = bounces[i];

    new_link->level = level;

    memcpy(new_link->digest, digest, SHA256_DIGEST_LENGTH * sizeof(char));

    return new_link;
}

int MREntry::get_size()
{
    return 2 * dimension * sizeof(double) + SHA256_DIGEST_LENGTH * sizeof(char) + sizeof(int);
}

MRTNode* MREntry::get_son()
{
    if(son_ptr == NULL)
        son_ptr = new MRTNode(my_tree, son);
    return son_ptr;
}

void MREntry::init_entry(int _dimension, MRTree *mrt)
{
    dimension = _dimension;
    my_tree = mrt;
    bounces = new double[2*dimension];
    son_ptr = NULL;
    son = 0;
    level = 0;
    memset(digest, 0x0, SHA256_DIGEST_LENGTH);
}

void MREntry::read_from_buffer(char *buffer)
{
    int i;
    i = 2 * dimension * sizeof(double);
    memcpy(bounces, buffer, i);
    
    memcpy(&son, &buffer[i], sizeof(int));

    i += sizeof(int);

    memcpy(&digest, &buffer[i], sizeof(char) * SHA256_DIGEST_LENGTH);

    i += sizeof(char) * SHA256_DIGEST_LENGTH;
}

void MREntry::write_to_buffer(char *buffer)
{
    int i;
    i = 2 * dimension * sizeof(double);
    memcpy(buffer, bounces, i);

    memcpy(&buffer[i], &son, sizeof(int));

    i += sizeof(int);

    memcpy(&buffer[i], &digest, sizeof(char) * SHA256_DIGEST_LENGTH);
    
    i += SHA256_DIGEST_LENGTH * sizeof(char);
}

SECTION MREntry::section(double *mbr)
{
    bool inside;
    bool overlap;

    overlap = TRUE;
    inside = TRUE;

    for (int i = 0; i < dimension; i++)
    {
        if (mbr[2 * i] > bounces[2 * i + 1] || mbr[2 * i + 1] < bounces[2 * i])
            overlap = FALSE;

        if (mbr[2 * i] < bounces[2 * i] || mbr[2 * i + 1] > bounces[2 * i + 1])
            inside = FALSE;
    }
    
    if (inside)
        return INSIDE;
    else if (overlap)
        return OVERLAP;
    else 
        return S_NONE;
}

void MREntry::set_from_Linkable(MRLinkable *link)
{
    son = link->son;
    dimension = link->dimension;
    memcpy(bounces, link->bounces, 2 * dimension * sizeof(double));

    level = link->level;
    memcpy(digest, link->digest, SHA256_DIGEST_LENGTH * sizeof(unsigned char));

    my_tree = NULL;
    son_ptr = NULL;
}

void MREntry::compute_digest(bool is_leaf)
{
    size_t total_length;
    unsigned char* buffer;
    if(is_leaf)
    {
        total_length = 2 * dimension * sizeof(double);
        buffer = new unsigned char[total_length];
        memcpy(buffer, bounces, 2 * dimension * sizeof(double));
        SHA256(buffer, total_length, digest);
    }
    else
    {
        total_length = 2 * dimension * sizeof(double) + SHA256_DIGEST_LENGTH * sizeof(unsigned char);
        buffer = new unsigned char[total_length];
        memcpy(buffer, bounces, 2 * dimension * sizeof(double));
        memcpy(buffer + (2 * dimension * sizeof(double)), son_ptr->digest, SHA256_DIGEST_LENGTH);

        SHA256(buffer, total_length, digest);

    }
    delete[] buffer;
}

bool MREntry::operator==(MREntry &_d)
{
    if(son != _d.son)
        return false;
    if(dimension != _d.dimension)
        return false;
    for(int i = 0; i < 2 * dimension; i++)
    {
        if(fabs(bounces[i] - _d.bounces[i]) > doubleZERO)
            return false;
    }
    if(memcmp(digest, _d.digest, SHA256_DIGEST_LENGTH) != 0)
        return false;
    return true;
}

MREntry& MREntry::operator=(MREntry &_d)
{
    dimension = _d.dimension;
    son = _d.son;
    son_ptr = _d.son_ptr;
    memcpy(bounces, _d.bounces, 2 * dimension * sizeof(double));
    level = _d.level;
    memcpy(digest, _d.digest, SHA256_DIGEST_LENGTH * sizeof(char));
    my_tree = _d.my_tree;
    return *this;
}